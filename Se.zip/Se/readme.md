Ce projet a été réalisé par les etudiants, 
==================================================
            ***KAYINDA MWATA Immaculé***
            ***NZUZI DIAVANGAMA Nehemie***
            ***MATONDO KAKUTU Jireh***
            ***MUWAWA YUMBU Laurette***
            ***KUTALANA MUSITU Divin***
            ***TITI Emmanuel***
            ***LOTOLA OMBA Aaron***
            ***OMONOMBE YUNGU Doché***
            ***MAKWANYA BONGOMBE Joel***
            ***SEMAGANYA FURAH Bienvenue***
==================================================


Dans ce travail, vu la forme de la question, nous nous sommes focalisé sur le fait de le faire /
comme un exposé dans lequel nous parlons de la compression en general et de quelsques outils de compression
sous linux en particulier. 

Dans le premier chapitre nous avons parlé de la compression au sens technique. Nous avons evoqué les deux
type de compression qu'il y a dans le monde, la compression sans perte et avec perte. Nous avons aussi brievement parlé de la decompression étant l'action inverse de la compression. Dans d'autres sections nous avons citer les 
utilitées de la compression dans la vie expliqué pour quoi ils sont si important.


Dans le second chapitre nous avons parlé des logiciels ci-après: GNU zi(gzip), bzip2 et enfin tar. 
Nous avons parlé de ces logiciels en long et en large en faisant attention à ne pas trop entrer dans les details
puisque ce travail, si nous pouvons nous permettre de le rappeller, a pour but de presenter ces outils en les 
survolant. 

============================================
               ***BIBLIOGRAPHIE***           
============================================

Pour ce travail nous nous sommes essentiellement basé sur la documentation de ubuntu https://doc.ubuntu.org
et de certain autres articles notament 
-    https://www.sourceware.org/bzip2/ et 
https://www.it-connect.fr/-comment-compresser-et-decompresser-tar-bz2-sous-linux/,
-    https://www.gnu.org/software/gzip/ 
et pour finir, le collaborateur de toute personne qui fait un exposé, le site incontournable de tous, 
WIKIPEDIA. 
============================================
              ***NOTE DE FIN***         
============================================
La difficulté de ce travail résidait dans le fait que reunir le travail de chacun et tirer le meilleur de tous, 
tout en sachant garder la lecture de ce travail potable de sorte que toute personne qui le lira pourra déjà avoir un 
bref appercu de ce qu'est linux, ou plus particulierement, UBUNTU. 